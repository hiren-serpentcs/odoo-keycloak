from . import test_auth
from . import test_wizard_sync
from . import test_wizard_create
