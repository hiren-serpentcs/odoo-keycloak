

class OAuthError(Exception):
    pass
