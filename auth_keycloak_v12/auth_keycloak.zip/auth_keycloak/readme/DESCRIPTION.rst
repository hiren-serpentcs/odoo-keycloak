This module adds support for SSO authentication via `Keycloak <https://www.keycloak.org/>`_
