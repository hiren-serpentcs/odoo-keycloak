Development sponsored by `Sensefly <https://www.sensefly.com/>`_ and `UTB <http://www.utb.fr/>`_.
