Settings -> Users -> OAuth Providers -> Keycloak

Adjust endpoints according to your setup.

Enable it: tick "Allowed".

Official docs: https://www.keycloak.org/docs


.. note:: You must make sure your settings are correct.
   Testing scripts are provided by this module in the folder `examples`.

   Please follow instructions contained in its README.
